module.exports.nothing = function(req, res) {
    res.render("pop", {
    });
};