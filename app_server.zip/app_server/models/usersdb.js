const mongoose = require('mongoose');
var bcrypt = require('bcryptjs');

const watch_schema=mongoose.Schema({
    cinema_name : {
        type : String,
        required : true

    },
    movie_name : {
        type : String,
        required : true

    },
    rating2 : {
        type : Number,
        required : true

    }
});

//pre hook 
/*user_schema.pre("save",function(next){
var user=this;
bcrypt.hash(user.password,10,function(err,hash){
if(err){
return next(err);
}
user.password=hash;
next();
})
});*/
//define schema here
const user_schema=mongoose.Schema({
    
    username : {
        type : String,
        required : true

    },
    password : {
        type : String,
        required : true

    },
    email: {
        type : String,
        required : true

    },
    city : {
        type : String,
        required : true

    },
    watchhist:[
        watch_schema
    ]

    
});
//authenticate input against database
user_schema.statics.authenticate = function(username, password, callback) {
    usersdb.findOne({ username: username }).exec(function(err, user) {
      if (err) { 
        Console.log("error in authenticate");  
        return callback(err); 
      } else if (!user) { 
        var err = new Error("User not found.");
        err.status = 401;
        return callback(err);
      }
      bcrypt.compare(password, user.password, function(err, result) { 
        if (result === true) {  
          return callback(null, user);
        } else {  
          return callback();  
        } 
      });  
    });  
  };
  
  //hashing a password before saving it to the database 
  user_schema.pre("save", function(next) {
    var user = this; 
    bcrypt.hash(user.password, 10, function(err, hash) { 
      if (err) {
        return next(err);
      }
      user.password = hash; 
      next();
    }); 
  });  
  
var usersdb = mongoose.model("usersdb", user_schema);
module.exports = usersdb;

module.exports.createUser = function(newUser, callback){
	bcrypt.genSalt(10, function(err, salt) {
	    bcrypt.hash(newUser.password, salt, function(err, hash) {
	        newUser.password = hash;
	        newUser.save(callback);
	    });
	});
}

module.exports.getUserByUsername = function(username, callback){
	var query = {username: username};
	User.findOne(query, callback);
}

module.exports.getUserById = function(id, callback){
	User.findById(id, callback);
}

module.exports.comparePassword = function(candidatePassword, hash, callback){
	bcrypt.compare(candidatePassword, hash, function(err, isMatch) {
    	if(err) throw err;
    	callback(null, isMatch);
	});
}

//var usersdb = module.exports = mongoose.model('usersdb',user_schema); 