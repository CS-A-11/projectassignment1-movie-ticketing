var mongoose = require("mongoose");
var express = require('express');
var request = require("request");
var payment = mongoose.model("payment1");
var user_schema = mongoose.model("usersdb");
var session=require("express-session");
//var apiOptions = {
  //  server: "http://localhost:3000"
 // }
//var user=require('../models/usersdb');
module.exports.savePop=function(request,response)
{
    var select_seats=request.body.seat; 
    //globalString=request.params.movie_title;
    //var data ={'value':select_seats};
    //globalString += select_seats;
    //globalString += " world";
    console.log(select_seats);
   // response.redirect('/cinemalist.html/:'+select_seats,200);
}
module.exports.nothing = function(req, res) {
    
    res.render("pop");
};

module.exports.creating = function(req, res) {
console.log(req.body);

if (req.body.username && req.body.email && req.body.password && req.body.password2) {
    var usersdb = {
      city : req.body.city,
      email: req.body.email,
      username: req.body.username,
      password: req.body.password,
    }

    //use schema.create to insert data into the db
    user_schema.create(usersdb, function (err, user) {
      if (err){
        consloe.log(err);
      } else { 
        globalstring=req.body.username;
        
        res.redirect('/index.html');

      }
    });
  }
};
module.exports.creating2 = function(req, res) {
  var sess=req.session;
  //sess.username=req.body.username;
if (req.body.username && req.body.password) {
    user_schema.authenticate(req.body.username, req.body.password, function(error, user) {
      if (error || !user) {
        var err = new Error("Wrong email or password.");
        err.status = 401;
        console.log('user not found');
        //console.log(err);
        //sendJSONresponse(res, 401, err);
        res.render('signin.html');
      } else {
          console.log('user found');
          globalstring=req.body.username;
         // sess.username=req.body.username;
         // sess.username=req.body.username;
          res.redirect('index.html');
        //sendJSONresponse(res, 200, user);
      }
    });
    
   // res.render('index.html');
  } 
  else {
    var err = new Error("All fields required.");
    err.status = 400;
    //sendJSONresponse(res, 400, err);
  }
};