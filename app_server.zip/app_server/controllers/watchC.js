var session =require('express-session');

module.exports.nothing3 = function(req, res,next) {
  /*  if(req.sess && req.sess.username){
    res.render('watchhist.html');
    }
    else{
        console.log("You must be logged in to view this page.");
    }
*/
   // sess = req.session;
    //if(sess.username) {
    //res.write('<h1>Hello '+sess.username+'</h1>');
    res.render("watchhist.html", {
        watch1:[
            {
                id:1,
                cine_n:"Cinegold",
                movie_n:"Parwaz hai junoon",
                
            },
            {
                id:2,
                cine_n:"universal",
                movie_n:"jpna 2",
                
            }
        ]
    });
    //res.end('<a href="+">Logout</a>');
    
    /*else {
        res.write('<h1>Please login first!</h1>');
        res.end('<a href="+">Login</a>');
    }
    */
};

module.exports.checkLogin = function requiresLogin(req, res, next) {
    if (req.session && req.session.username) {
       // if(session.username){
      console.log("session active");
      next();
    } else {
      console.log("no session active");
      var err = new Error("You must be logged in to view this page.");
      err.status = 401;
      //console.log(err);
      res.redirect("/");
    }
  };