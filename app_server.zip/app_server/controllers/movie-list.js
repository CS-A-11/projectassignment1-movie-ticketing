

module.exports.movielist = function(req, res) {
    res.render("index.html", {



       /* movie1:
        [
            {
              id:1,
              title:"sultan",
              rating:4.5,
              genre:"zdjk",
              language:"english",
              description:"sdjkkkkk"
            }
            ,
            {
              
                id:3,
                title:"sultan3",
                rating:4.6,
                genre:"zdj333k",
                language:"engli333sh",
                description:"sdjk3333kkkk"
              
            },
            {
              
                
                id:4,
                title:"sultdan3",
                rating:3.6,
                genre:"zdj3ddd33k",
                language:"engli3sdsd33sh",
                description:"sdjk3333sdsdskkkk"
              
            } 
          
        ]
        */
    
        });};

       