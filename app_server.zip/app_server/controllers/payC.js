var request = require("request");
var bodyParser=require("body-parser");
var mongoose = require("mongoose");


//require('../models/usersdb');
var usersdb=require('../models/usersdb');
var payment1=require('../models/payment');
var watchhist1=require('../models/watchhist');
module.exports.nothing1 = function(req, res) {
    res.render("payment.html", {
    });
};
//post req on index.html
module.exports.getmovie = function(req, res) {

//console.log("Yes it comes here ");
payment1.find({username: globalstring}, ["_id"]).exec( 
    function(err, payment) {
		if(payment1._id==null)
		{
			pay=new payment1(
				{
					username:globalstring
				});
			pay.save(function(error) {
				 console.log("Your user has been saved!");
			 if (error) {
					 console.error(error);
				 }
				}
			)
	}
	else
	console.log("Your user exists");
	console.log("req.body post"+req.body);
    }
);
	
		/*pay=new payment1(
			{
				username:username
			});
		pay.save(function(error) {
		     console.log("Your user has been saved!");
		 if (error) {
			     console.error(error);
			 }
	}
		)
		*/


	
};
module.exports.getmovie1 = function(req, res) {
	var movie=req.params.movie;
	console.log(globalstring);
	//payment1
		//.find(globalstring)
		//.exec(function(err,payment){

			
				//payment1.movie_name=movie;
				//console.log("21");
				payment1.update({ username: globalstring }, { $set: { movie_name: movie }}, function (err, payment) {
					if (err) return handleError(err);
					res.send(payment);
				  });
		//}
		//)
		
	
		
	};
	module.exports.getmovie2 = function(req, res) {
		var seats=req.params.seats;
		console.log(globalstring);
		//payment1
			//.find(globalstring)
			//.exec(function(err,payment){
	
				
					//payment1.movie_name=movie;
					//console.log("21");
					payment1.update({ username: globalstring }, { $set: {  select_seats: seats}}, function (err, payment) {
						if (err)console.log(err);
						res.send(payment);
					  });
			//}
			//)
			
		
			
		};
		module.exports.getcinema = function(req, res) {
			var name=req.params.name;
			//console.log("name"+name);
						payment1.update({ username: globalstring }, { $set: {  cinema_name: name}}, function (err, payment) {
							if (err) return handleError(err);
							res.send(payment);
						  });
				//}
				//)
			}; 
			module.exports.displaySummary = function(req, res) {
			
				var user=globalstring;
				
				//console.log(user);
				

				payment1.find({
					username: user

				}).exec(function(err,payment){
					if (err) return handleError(err);
					else {
						//console.log(payment);
						//console.log(payment1);
					
					
						res.render("paymentsummary.html", { data: payment });

					}

				});			
			}
	module.exports.displayWatch = function(req, res) {
			
					var user=globalstring;
					var c;
					var m;
					
	
					var query=payment1.find({
						username: user
					})
					query.select('movie_name cinema_name');
					query.exec(function(err,payment){
						if (err) return handleError(err);
						else {
						console.log("payment"+payment);
						c=payment[0].cinema_name;
			        	m=payment[0].movie_name;
						console.log("movie"+payment[0].movie_name);
							
						}
					
					
					
					watch =new watchhist1({
						username:user,
						cinema_name:c,
						movie_name: m
	
					})
					console.log("watch"+watch);
					watch.save(function(error) {
						if (error) return handleError(error);
					   }
				   )
				})	
				watchhist1.find({
					username:user
				})
				.exec(function(err,watchhist){
					if(err)return handleError(err);
					else
					{		console.log("my        "+watchhist)
							res.render("watchhist.html", { data: watchhist});
					}
				})
				}
			


				/*payment1
					.find({ username : user })
					.exec(function (err, payment) {
 					 if (err) return handleError(err);
						  
						  console.log(payment1.username);
							});*/
			
  



module.exports.userCreate = function(req, res) {
	
	console.log(req.body);
    var city1= req.body.city;
	 console.log(city1);
	//var email = req.body.email;
	//var username = req.body.username;
	//var password = req.body.password;
	//var password2 = req.body.password2;
	//remove name and add city
	
	/*// Validation
	req.checkBody('city', 'city is required').notEmpty();
	req.checkBody('email', 'Email is required').notEmpty();
	req.checkBody('email', 'Email is not valid').isEmail();
	req.checkBody('username', 'Username is required').notEmpty();
	req.checkBody('password', 'Password is required').notEmpty();
	req.checkBody('password2', 'Passwords do not match').equals(req.body.password);

	var errors = req.validationErrors();

	if (errors) {
		res.render('signup.html', {
			errors: errors
		});
	}
	else {
		//checking for email and username are already taken
		usersdb.findOne({ username: { 
			"$regex": "^" + username + "\\b", "$options": "i"
	}}, function (err, usersdb) {
			usersdb.findOne({ email: { 
				"$regex": "^" + email + "\\b", "$options": "i"
		}}, function (err, mail) {
				if (user || mail) {
					res.render('signup.html', {
						user: user,
						mail: mail
					});
				}
				else {
					var newUser = new usersdb({
						city: city,
						email: email,
						username: username,
						password: password
					});
					usersdb.createUser(newUser, function (err, usersdb) {
						if (err) throw err;
						console.log(user);
					});
         	req.flash('success_msg', 'You are registered and can now login');
					res.redirect('signin.html');
				}
			});
		});
	}
	*/
};

