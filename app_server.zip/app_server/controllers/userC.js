var mongoose = require("mongoose");
var express = require('express');
var request = require("request");
var user_schema = mongoose.model("usersdb");
module.exports.nothing2 = function(req, res) {
    user_schema.findOne({
         username:globalstring
    }).exec(function(err,usersdb){
        if (err) return handleError(err);
        else {
            //console.log(payment);
            console.log(usersdb);
        
        
            res.render("user.html", { data1: usersdb});

        }

    });	
};
    /*
    res.render("user.html", {
        user_n:"Mark",
        city:"Karachi",
        email:"markZucker@gmail.com",
        phone:"0321-3245237"

    });
*/


module.exports.checkLogin = function requiresLogin(req, res, next) {
    //
    if (req.session && req.session.username) {
      console.log("session active");
      next();
    } else {
      console.log("no session active");
      var err = new Error("You must be logged in to view this page.");
      err.status = 401;
      res.redirect("/");
    }
  };